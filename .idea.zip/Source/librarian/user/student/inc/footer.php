			
			</div>
		</div>
	</div>

    <div class="footer text-center">
        <p>&copy; All rights reserved utter pompously</p>
    </div>

	<script src="inc/js/jquery-2.2.4.min.js"></script>
	<script src="inc/js/bootstrap.min.js"></script>
	<script src="inc/js/waypoints.min.js"></script>
	<script src="inc/js/jquery.counterup.min.js"></script>
	<script src="inc/js/datatables.min.js"></script>
	<script src="inc/js/datatables.js"></script>
	<script src="inc/js/custom.js"></script>
</body>
</html>