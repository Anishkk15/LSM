# Lms
Lms is a web application that exactly build for college and university base library management system. It built in simple raw php and simple database design.
